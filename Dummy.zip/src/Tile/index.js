import React from "react";

const Tile = ({ index }) => {
  return <div className={`tile${index}`}>Tile</div>;
};

export default Tile;
